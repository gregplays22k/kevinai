KEVIN — GitHub Pages setup

1. Extract this ZIP.
2. Open your GitHub repository.
3. Upload these files to the repository root: index.html, manifest.json, kevin-icon.png.
   (You can also upload this README, but it is not required.)
4. If you already have Kevin.html, use index.html as the site homepage. Do not upload two different versions and expect GitHub Pages to know which one you want.
5. Go to repository Settings > Pages. Choose Deploy from a branch, branch main, folder /(root), then Save.
6. Wait for the published https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/ link.
7. On iPad, open that link in Safari > Share > Add to Home Screen. Enable Open as Web App if shown, then Add. Launch Kevin from the new Home Screen icon.

Notes:
- This adds the web-app manifest, iOS Home Screen metadata, icon, and safe-area support. iPadOS versions can vary; Add to Home Screen is what creates the app-style shortcut.
- This is a website, not a native App Store app. Internet features require internet. Timers run while the page is active; background behavior is controlled by iPadOS.
- Do not publish API keys, passwords, or private data in a public repository.
